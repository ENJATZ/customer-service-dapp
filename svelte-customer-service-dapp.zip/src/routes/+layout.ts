export const ssr = false;
export const prerender = false;

import { Buffer } from 'buffer';
globalThis.Buffer = Buffer;
