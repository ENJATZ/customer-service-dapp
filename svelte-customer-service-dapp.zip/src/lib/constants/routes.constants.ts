export enum AppPath {
	Authentication = '/',
	Canister = '/canister'
}

export const CANISTER_PARAM = 'canisterId';
