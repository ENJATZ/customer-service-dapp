import type { HttpAgent } from '@dfinity/agent';
import type { Readable } from 'svelte/store';
import { writable } from 'svelte/store';

export interface AuthStoreData {
	agent: HttpAgent | undefined | null;
}

export interface AuthStore extends Readable<AuthStoreData> {
	setAgent: (agent: HttpAgent) => Promise<void>;
	signOut: () => Promise<void>;
}

const initAuthStore = (): AuthStore => {
	const { subscribe, set, update } = writable<AuthStoreData>({
		agent: undefined
	});

	return {
		subscribe,
		setAgent: async (agent: HttpAgent) => {
			set({
				agent
			});
		},

		signOut: async () => {
			update((state: AuthStoreData) => ({
				...state,
				agent: null
			}));
		}
	};
};

export const authStore = initAuthStore();
