<script lang="ts">
	import { ConnectButton, ConnectDialog, useConnect, useCanister } from '@connect2ic/svelte';
	import '@connect2ic/core/style.css';
	const { principal } = useConnect({
		onConnect: () => {
			console.log('🚀 ~ file: nav-bar.svelte:13 ~ principal:', principal);
			console.log('signed in');
		},
		onDisconnect: () => {
			// Signed out
		}
	});
	const [actor] = useCanister('main');
	console.log('🚀 ~ file: nav-bar.svelte:15 ~ actor:', $actor);
</script>

<div>
	<ConnectButton />
	<ConnectDialog />
</div>
